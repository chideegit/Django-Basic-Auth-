from django.shortcuts import render, redirect
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout, update_session_auth_hash
from django.contrib.auth.forms import PasswordChangeForm
from django.contrib.auth.decorators import login_required

from .form import RegisterUserForm

@login_required
def home(request):
    return render(request, 'accounts/home.html')

# register user 
def register_user(request):
    if request.method == 'POST':
        form = RegisterUserForm(request.POST)
        if form.is_valid():
            form.save()
            messages.info(request, 'Your account is now created')
            return redirect('login')
        else:
            messages.warning(request, 'Something went wrong')
            return redirect('register')
    else:
        form = RegisterUserForm()
        context = {'form':form}
        return render(request, 'accounts/register.html', context)


# login user 
def login_user(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')

        user = authenticate(request, username=username, password=password)
        if user is not None and user.is_active:
            login(request, user)
            return redirect('home')
        else:
            messages.warning(request, 'Something went wrong')
            return redirect('login')
    else:
        return render(request, 'accounts/login.html')


# logout user 
def logout_user(request):
    logout(request)
    messages.info(request, 'Your session has ended. Log in to continue')
    return redirect('login')


# change password in the app
def change_password(request):
    if request.method == 'POST':
        form =PasswordChangeForm(request.user, request.POST)
        if form.is_valid():
            user = form.save()
            update_session_auth_hash(request, user)
            messages.info(request, 'Your password was successfully updated')
            return redirect('home')
        else:
            messages.warning(request, 'Something went wrong')
            return redirect('password-change')
    else:
        form = PasswordChangeForm(request.user)
        context = {'form':form}
        return render(request, 'accounts/change_password.html', context)


